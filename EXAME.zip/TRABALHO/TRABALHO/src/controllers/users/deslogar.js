async function deslogar(res){
    res.clearcookie('token');
    res.redirect('/')
}

module.exports = deslogar
