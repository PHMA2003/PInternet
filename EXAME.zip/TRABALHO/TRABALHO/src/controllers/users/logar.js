const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');


async function Logar(body){
    // RECEBE OS DADOS DO USUÁRIO.
    const email = body.email;
    const senha = body.senha;

    // VERIFICA OS DADOS.
    if (!email || !senha) {
        return { erro: 'Dados insuficientes.' };
    }

    // BUSCA O USUÁRIO NO BANCO.
    try {
        const user = await User.findOne({ email, senha }).exec();
        if (!user) {
            return { erro: 'E-mail ou senha incorretos.' };
        }

        // SE ENCONTROU, GERA O TOKEN.
        const token = jwt.sign({
            id: user._id,
            nome: user.nome,
            email: user.email,
        }, 'chaveSecretaParaGerarOToken');

        // SALVA O TOKEN NOS COOKIES DO NAVEGADOR.
        res.cookie('Token', token, { httpOnly: true });
        res.sendStatus(200);
    } catch (erro) {
        return { erro: erro.message };
    }
}

module.exports = Logar;
