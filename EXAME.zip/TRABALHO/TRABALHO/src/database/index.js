const mongoose = require('mongoose');


mongoose.connect('mongodb://localhost:27017/TRABALHO')
  .then(() => {
    console.log("MongoDB online.");
  }).catch(erro => {
    console.log(erro);
  });

db = mongoose.connection;

module.exports = db;
