const express = require('express');
const multer = require('multer');
const cookieParser = require('cookie-parser');
const app = express();
const port = 3000;

// Configuração do Multer para upload de arquivos
const storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function(req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + file.originalname);
    }
});
const upload = multer({ storage: storage });

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());


app.post('/cadastrar', upload.single('petPhoto'), (req, res) => {
    console.log('Dados recebidos:', req.body);
    console.log('Arquivo:', req.file);

  
    res.cookie('ultimoCadastro', req.body.nomePet, { maxAge: 900000, httpOnly: true });

    res.send('Cadastro realizado com sucesso!');
});

app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});
